# Ansible Collection - my_own_namespace.my_own_collection

Documentation for the collection.

- my_own_collection
  - my_own_module.py
  - single_tas_role
